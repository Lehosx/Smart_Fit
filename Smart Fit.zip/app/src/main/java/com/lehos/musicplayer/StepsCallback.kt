package com.lehos.musicplayer

interface stepsCallback {
    fun subscribeSteps(steps: Int)
}